<table class="table table-condensed">
    <thead>
        <tr>
            <th>
                Title
            </th>
            {{--
            <th>
                Email
            </th>
            <th>
                Role
            </th>
            --}}
        </tr>
    </thead>
    <tbody>
        @forelse($informations as $information)
        <tr>
            <td>
                {{$information->title}}
            </td>
            {{--
            <td>
                {{$user->email}}
            </td>
            <td>
                {{$user->role->title}}
            </td>
            --}}
          
        </tr>
        @empty
        <tfoot>
            <tr>
                <td>
                    Nothing Found!
                </td>
            </tr>
        </tfoot>
        @endforelse
    </tbody>
</table>