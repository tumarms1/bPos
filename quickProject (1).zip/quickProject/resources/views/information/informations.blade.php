@extends('layouts.app')

@section('content')
<form method="POST" action="{{route('downloadPDF')}}">
 @csrf
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8">Users</div>
                        @if(auth()->user()->role_id==2)
                        <div class="col-md-2"><button class="btn btn-primary btn-sm" id="addUser">Add</button></div>
                        <div class="col-md-2"><button type="submit" class="btn btn-primary btn-sm" >PDF</button></div>
                        @endif
                    </div>
                </div>

                <div class="card-body">
          
                    @include('error.alert')
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-condensed">
                                <thead>
                                    <tr>
                                        <th>
                                            
                                        </th>
                                        <th>
                                            Title
                                        </th>
                                  {{--       <th>
                                            Email
                                        </th>
                                        <th>
                                            Role
                                        </th> --}}
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @forelse($informations as $information)
                                    <tr>
                                        <td><input type="checkbox" name="checkbox[]" value="{{$information->id}}"></td>
                                        <td>
                                            {{$information->title}}
                                        </td>
                                  {{--       <td>
                                            {{$user->email}}
                                        </td>
                                        <td>
                                            {{$user->role->title}}
                                        </td> --}}
                                        <td><a href="{{route('downloadPDF')}}">PDF</a></td>

                                    </tr>
                                   
                                  
                                    @empty
                                    <tfoot>
                                        <tr>
                                            <td>
                                                Nothing Found!
                                            </td>
                                        </tr>
                                    </tfoot>
                                    @endforelse
                                </tbody>

                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
</form>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <form action="{{route('information.store')}}" method="POST">
        @csrf
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Add Information</h4>

              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                        <div class="form-group row">
                            <label for="name" class="col-sm-4 col-form-label text-md-right">{{ __('Title') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="title" value="{{ old('name') }}" required autofocus>

                 
                            </div>
                        </div>
                       {{--  <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                            </div>
                        </div>
                         <div class="form-group row">
                            <label for="Role" class="col-md-4 col-form-label text-md-right">{{ __('Role') }}</label>

                            <div class="col-md-6">
                               <select class="form-control" name="role">
                                   @forelse($roles as $role)
                                   <option value="{{$role->id}}">{{$role->title}}</option>
                                   @empty
                                   @endforelse
                               </select>

                            </div>
                        </div> --}}
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-success" >Save</button>
            </div>
          </div>
      </form>
      
    </div>
  </div>

<script type="text/javascript">
    $(function(){
        $("#addUser").click(function(){
            $("#myModal").modal();
        });
    })
</script>
@endsection

