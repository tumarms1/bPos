<table class="table table-condensed">
    <thead>
        <tr>
            <th>
                Title
            </th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td>
                <?php echo e($information->title); ?>

            </td>
            
          
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tfoot>
            <tr>
                <td>
                    Nothing Found!
                </td>
            </tr>
        </tfoot>
        <?php endif; ?>
    </tbody>
</table>