<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('downloadPDF')); ?>">
 <?php echo csrf_field(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8">Users</div>
                        <?php if(auth()->user()->role_id==2): ?>
                        <div class="col-md-2"><button class="btn btn-primary btn-sm" id="addUser">Add</button></div>
                        <div class="col-md-2"><button type="submit" class="btn btn-primary btn-sm" >PDF</button></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card-body">
          
                    <?php echo $__env->make('error.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-condensed">
                                <thead>
                                    <tr>
                                        <th>
                                            
                                        </th>
                                        <th>
                                            Title
                                        </th>
                                  
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__empty_1 = true; $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><input type="checkbox" name="checkbox[]" value="<?php echo e($information->id); ?>"></td>
                                        <td>
                                            <?php echo e($information->title); ?>

                                        </td>
                                  
                                        <td><a href="<?php echo e(route('downloadPDF')); ?>">PDF</a></td>

                                    </tr>
                                   
                                  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tfoot>
                                        <tr>
                                            <td>
                                                Nothing Found!
                                            </td>
                                        </tr>
                                    </tfoot>
                                    <?php endif; ?>
                                </tbody>

                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
</form>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <form action="<?php echo e(route('information.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Add Information</h4>

              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                        <div class="form-group row">
                            <label for="name" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Title')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="title" value="<?php echo e(old('name')); ?>" required autofocus>

                 
                            </div>
                        </div>
                       
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-success" >Save</button>
            </div>
          </div>
      </form>
      
    </div>
  </div>

<script type="text/javascript">
    $(function(){
        $("#addUser").click(function(){
            $("#myModal").modal();
        });
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>